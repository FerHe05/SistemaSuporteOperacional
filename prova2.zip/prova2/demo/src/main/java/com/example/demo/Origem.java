package com.example.demo;


enum Origem {
    APP,
    SITE,
    EMAIL
}