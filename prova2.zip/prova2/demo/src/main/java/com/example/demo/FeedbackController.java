package com.example.demo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/feedbacks")
public class FeedbackController {

    @Autowired
    private FeedbackRepository feedbackRepository;

    // Endpoint para criar um novo feedback
    @PostMapping
    public Feedback criarFeedback(@RequestBody Feedback feedback) {
        return feedbackRepository.save(feedback);
    }

    // Endpoint para listar todos os feedbacks
    @GetMapping
    public List<Feedback> listarFeedbacks() {
        return feedbackRepository.findAll();
    }

    // Endpoint para buscar feedbacks por origem
    @GetMapping("/origem/{origem}")
    public List<Feedback> buscarPorOrigem(@PathVariable Origem origem) {
        return feedbackRepository.findByOrigem(origem);
    }

    // Endpoint para definir prioridade em um feedback
    @PatchMapping("/{id}/prioridade")
    public ResponseEntity<Feedback> definirPrioridade(@PathVariable Long id, @RequestParam boolean prioridade) {
        return feedbackRepository.findById(id).map(feedback -> {
            feedback.setPrioridade(prioridade);
            feedbackRepository.save(feedback);
            return ResponseEntity.ok(feedback);
        }).orElse(ResponseEntity.notFound().build());
    }
}
