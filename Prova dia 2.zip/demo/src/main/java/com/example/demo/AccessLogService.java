package com.example.demo;

import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class AccessLogService {
    private final AccessLogRepository repository;

    public AccessLogService(AccessLogRepository repository) {
        this.repository = repository;
    }

    public List<AccessLog> findAll() {
        return repository.findAll();
    }

    public AccessLog save(AccessLog accessLog) {
        return repository.save(accessLog);
    }
}