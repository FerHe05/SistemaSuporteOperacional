package com.example.demo;

import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/access-logs")
public class AccessLogController {
    private final AccessLogService service;

    public AccessLogController(AccessLogService service) {
        this.service = service;
    }

    @GetMapping
    public List<AccessLog> getAllLogs() {
        return service.findAll();
    }

    @PostMapping
    public AccessLog createLog(@RequestBody AccessLog accessLog) {
        return service.save(accessLog);
    }
}