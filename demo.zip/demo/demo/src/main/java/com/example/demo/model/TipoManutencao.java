package com.example.demo.model;

public enum TipoManutencao {
    CORRETIVA,
    PREVENTIVA
}
