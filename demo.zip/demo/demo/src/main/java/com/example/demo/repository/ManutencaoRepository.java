package com.example.demo.repository;

import com.example.demo.model.TipoManutencao;
import com.example.demo.model.Manutencao;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.time.LocalDate;
import java.util.List;

public interface ManutencaoRepository extends JpaRepository<Manutencao, Long> {

    List<Manutencao> findByTipoManutencao(TipoManutencao tipoManutencao);

    @Query("SELECT COUNT(m) FROM Manutencao m WHERE m.dataRealizacao = :dataRealizacao")
    Long countByDataRealizacao(LocalDate dataRealizacao);

    @Query("SELECT COUNT(m) FROM Manutencao m WHERE m.idEquipamento = :idEquipamento")
    Long countByIdEquipamento(Long idEquipamento);
}