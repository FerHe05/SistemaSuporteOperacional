package com.example.demo.service;

import com.example.demo.model.Manutencao;
import com.example.demo.model.TipoManutencao;

import com.example.demo.repository.ManutencaoRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

@Service
public class ManutencaoService {

    @Autowired
    private ManutencaoRepository manutencaoRepository;

    public List<Manutencao> listarTodas() {
        return manutencaoRepository.findAll();
    }

    public Optional<Manutencao> buscarPorId(Long id) {
        return manutencaoRepository.findById(id);
    }

    public Manutencao criarManutencao(Manutencao manutencao) {
        return manutencaoRepository.save(manutencao);
    }

    public Manutencao atualizarManutencao(Long id, Manutencao manutencaoAtualizada) {
        Optional<Manutencao> manutencaoExistente = manutencaoRepository.findById(id);
        if (manutencaoExistente.isPresent()) {
            Manutencao manutencao = manutencaoExistente.get();
            manutencao.setDescricao(manutencaoAtualizada.getDescricao());
            manutencao.setTipoManutencao(manutencaoAtualizada.getTipoManutencao());
            manutencao.setDataRealizacao(manutencaoAtualizada.getDataRealizacao());
            manutencao.setTempoGasto(manutencaoAtualizada.getTempoGasto());
            manutencao.setAtivo(manutencaoAtualizada.getAtivo());
            return manutencaoRepository.save(manutencao);
        }
        return null;
    }

    public void excluirManutencao(Long id) {
        manutencaoRepository.deleteById(id);
    }

    public List<Manutencao> listarPorTipoManutencao(TipoManutencao tipoManutencao) {
        return manutencaoRepository.findByTipoManutencao(tipoManutencao);
    }

    public Long contarPorDataRealizacao(LocalDate dataRealizacao) {
        return manutencaoRepository.countByDataRealizacao(dataRealizacao);
    }

    public Long contarPorEquipamento(Long idEquipamento) {
        return manutencaoRepository.countByIdEquipamento(idEquipamento);
    }
}
