package com.example.demo;

public enum Status {
    ABERTO,
    EM_ANDAMENTO,
    CONCLUIDO
}
